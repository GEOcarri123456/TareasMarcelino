import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Cuenta = () => {
  return (
    <View>
      <Text>CrearCuenta</Text>
    </View>
  )
}

export default Cuenta

const styles = StyleSheet.create({})