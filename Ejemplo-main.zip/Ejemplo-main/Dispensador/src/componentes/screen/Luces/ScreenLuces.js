import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const ScreenLuces = () => {
  return (
    <View>
      <Text>ScreenLuces</Text>
    </View>
  )
}

export default ScreenLuces

const styles = StyleSheet.create({})