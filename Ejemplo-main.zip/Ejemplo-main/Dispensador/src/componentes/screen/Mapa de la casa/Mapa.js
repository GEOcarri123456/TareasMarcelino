import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Mapa = () => {
  return (
    <View>
      <Text>Mapa</Text>
    </View>
  )
}

export default Mapa

const styles = StyleSheet.create({})