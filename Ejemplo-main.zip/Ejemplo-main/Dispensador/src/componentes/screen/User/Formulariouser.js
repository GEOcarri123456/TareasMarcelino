import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Formulariouser = () => {
  return (
    <View>
      <Text>Formulariouser</Text>
    </View>
  )
}

export default Formulariouser

const styles = StyleSheet.create({})