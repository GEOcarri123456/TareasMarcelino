import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Editaruser = () => {
  return (
    <View>
      <Text>Editaruser</Text>
    </View>
  )
}

export default Editaruser

const styles = StyleSheet.create({})