import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const UserDetalles = () => {
  return (
    <View>
      <Text>Nombre: Marce</Text>
      <Text>Info....</Text>
      <Text>Tel: 987653456</Text>
    </View>
  )
}

export default UserDetalles

const styles = StyleSheet.create({})